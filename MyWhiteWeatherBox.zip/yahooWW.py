import urllib
import BeautifulSoup
import sys
import time

while 1 :

        data = urllib.urlopen('https://weather.yahoo.com/')
        soup = BeautifulSoup.BeautifulSoup(data)
        now = soup.findAll('span', attrs={'class':'c'})
        temp = now[0].find('span').text

        name = soup.findAll('span', attrs={'class':'name'})
        temp1 = name[0].text
        temp2 = str(temp1)

        condition = soup.findAll('div', attrs={'class':'bd'})
        temp3 = condition[0].find('div').text
        temp4 = str(temp3)

        high = soup.findAll('span', attrs={'class':'hi c w-up-arrow'})
        temp5 = high[0].text
        temp6 = temp5[:2]

        low = soup.findAll('span', attrs={'class':'lo c w-down-arrow'})
        temp7 = low[0].text
        temp8 = temp7[:2]

        f = open("new",'w')

        f.write(temp)
        f.close()

        fn = open("name",'w')

        fn.write(temp2)
        fn.close()

        fc = open("condition",'w')

        fc.write(temp4)
        fn.close()

        fh = open("high",'w')

        fh.write(temp6)
        fh.close()

        fl = open("low",'w')

        fl.write(temp8)
        fl.close()



        time.sleep(1);

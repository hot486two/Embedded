#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include "lcd.c"
#include <string.h>

#define GPIO_PATH "/sys/class/gpio"
#define GPIO_LENGTH 10
#define tempPATH "/sys/devices/w1_bus_master1/28-001451c0c8ff#"

int main(void)
{
//                       RS  E   D0  D1  D2  D3
        char gpio[10] = {47, 46, 23, 26, 45, 44,
//                               D4  D5  D6  D7
                                 69, 68, 66, 67};
        FILE *gpio_fp[10];
        FILE *tmp_fp;

        char tmp_path[255];
        int i;

        for (i = 0; i < GPIO_LENGTH; i++)
        {
                tmp_fp = fopen(GPIO_PATH "/export", "w");
                fprintf(tmp_fp, "%d", gpio[i]);
                fclose(tmp_fp);

                sprintf(tmp_path, GPIO_PATH "/gpio%d/direction", gpio[i]);
                tmp_fp = fopen(tmp_path, "w");
                fprintf(tmp_fp, "out");
                fclose(tmp_fp);

                sprintf(tmp_path, GPIO_PATH "/gpio%d/value", gpio[i]);
                gpio_fp[i] = fopen(tmp_path, "w");
        }

        // LCD INITIALIZATION
        lcd_init(gpio_fp);

        FILE *fTemp =NULL;
        FILE *fOut = NULL;
        FILE *fWhere = NULL;
        FILE *fCondition = NULL;
        FILE *fHigh = NULL;
        FILE *fLow = NULL;

        char out [10];
        char where [50];
        char condition [50];
        char high [10];
        char low [10];

        char ondo [50];
        char ondo2 [50];
        char result[10];        

        char tp,tp2;

        int a,b,c,d,e;

        while(1){

                char first[16];
                char second[16];
                char first2[16];
                char second2[16];
            
                fTemp= fopen("/sys/devices/w1_bus_master1/28-001451c0c8ff/w1_slave","r");
                fOut = fopen("/root/WWB/new","r");
                fWhere = fopen("/root/WWB/name","r");
                fCondition = fopen("/root/WWB/condition","r");
                fHigh = fopen("/root/WWB/High","r");
                fLow = fopen("/root/WWB/Low","r");

                fgets(ondo,255,fTemp);
                fgets(ondo2,255,fTemp);
                sprintf(result,"%c%c",ondo2[29], ondo2[30]);
                
                fgets(out,255,fOut);

                a=atoi(result);
                b=atoi(out);

                if(a>b)
                        c=a-b;
                else
                        c=b-a;

                fgets(where,50,fWhere);

                fgets(condition,50,fCondition);

                fgets(high,10,fHigh); 
                fgets(low,10,fLow);

                d=atoi(high);
                e=atoi(low);
                
                sprintf(first2,"%s : %d'C----",where,b);
                sprintf(second,"InD:%d'C Gap:%d'C",a,c);

                // WRITE FIRST LINE
                lcd_send(FIRST_LINE, CMD_MODE);
                lcd_write(first2);

                // WRITE SECOND LINE
                lcd_send(SECOND_LINE, CMD_MODE);
                lcd_write(second);

                sleep(5);

                sprintf(first,"Cndi:%s",condition);
                sprintf(second2,"Hi:%d'C Lo:%d'C ",d,e);

                // WRITE FIRST LINE
                lcd_send(FIRST_LINE, CMD_MODE);
                lcd_write(first);

                // WRITE SECOND LINE
                lcd_send(SECOND_LINE, CMD_MODE);
                lcd_write(second2);

                sleep(5);


                fclose(fTemp);
                fclose(fOut);
                fclose(fWhere);
                fclose(fCondition);
                fclose(fHigh);
                fclose(fLow);

        }

        tmp_fp = fopen(GPIO_PATH "/unexport", "w");

                for (i = 0; i < GPIO_LENGTH; i++)
                {
                        fclose(gpio_fp[i]);
                        fprintf(tmp_fp, "%d", gpio[i]);
                }
                fclose(tmp_fp);
}
